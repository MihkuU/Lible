# CP2K Open Source Molecular Dynamics

The [CP2K recipe](https://xconfigure.readthedocs.io/cp2k/) ([PDF](https://github.com/hfp/xconfigure/raw/master/xconfigure.pdf)) has been incorporated into the XCONFIGURE project.
