Variable gather operations
==========================

Gathers data if varying size to a single process.

.. literalinclude:: ../../../examples/gather.cc
   :language: c++
