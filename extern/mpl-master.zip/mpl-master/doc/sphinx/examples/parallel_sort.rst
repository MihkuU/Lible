Parallel sorting
================

Parallel sort algorithm, MPI version.

.. literalinclude:: ../../../examples/parallel_sort_mpi.c
   :language: c


Parallel sort algorithm, MPL version.

.. literalinclude:: ../../../examples/parallel_sort_mpl.cc
   :language: c++
