Matrix gather
=============

Demonstrates gathering of a distributed matrix as it may used in domain partitioning applications.

.. literalinclude:: ../../../examples/matrix_gather.cc
   :language: c++
