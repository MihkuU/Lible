Non-blocking send and receive
=============================

Demonstrates non-blocking send and receive of standard data types and vectors of standard data types and different waiting methods.

.. literalinclude:: ../../../examples/nonblocking.cc
   :language: c++
