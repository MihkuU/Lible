Gather via non-blocking send and receive
========================================

Utilizes non-blocking send and receive of standard data types to implement a gather operation.

.. literalinclude:: ../../../examples/nonblocking_mult.cc
   :language: c++
