Subarray layouts
================

Construction and usage of subarray layouts.

.. literalinclude:: ../../../examples/subarray.cc
   :language: c++
