Blocking send and receive of vectors
====================================

Demonstrates blocking send and receive of a vector of standard data types.

.. literalinclude:: ../../../examples/blocking_vector.cc
   :language: c++
