Standard types
==============

Sends and receives data of various standard types.

.. literalinclude:: ../../../examples/standard_types.cc
   :language: c++
