Hello world
===========

Simple hello-world program. Initializes the message passing environment and determines the number of processes and rank.

.. literalinclude:: ../../../examples/hello_world.cc
   :language: c++
