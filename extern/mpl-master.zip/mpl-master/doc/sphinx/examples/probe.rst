Probing messages
================

Demonstrates how to probe data and to receive a message of unknown size.

.. literalinclude:: ../../../examples/probe.cc
   :language: c++
