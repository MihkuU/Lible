Collective communication
========================

Demonstrates various modes of collective communication.

.. literalinclude:: ../../../examples/collective.cc
   :language: c++
