File i/o
========

Simple program performing basic file-based i/o operations.

.. literalinclude:: ../../../examples/file.cc
   :language: c++
