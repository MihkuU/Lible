Communicator management
=======================

Demonstrates some basic communicator management.

.. literalinclude:: ../../../examples/communicator.cc
   :language: c++
