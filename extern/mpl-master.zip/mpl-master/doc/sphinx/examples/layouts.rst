Layouts
=======

Construction and usage of various data layouts.

.. literalinclude:: ../../../examples/layouts.cc
   :language: c++
