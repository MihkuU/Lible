STL containers
==============

Sends and receives STL containers.

.. literalinclude:: ../../../examples/stl_container.cc
   :language: c++
