Distributed grid
================

Data type ``mpl::distributed_grid`` in action.

.. literalinclude:: ../../../examples/distributed_grid.cc
   :language: c++
