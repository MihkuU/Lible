Blocking send and receive
=========================

Demonstrates various blocking send and receive modes of standard data types.

.. literalinclude:: ../../../examples/blocking.cc
   :language: c++
