Gather operations
=================

Gathers data to a single process.

.. literalinclude:: ../../../examples/gather.cc
   :language: c++
