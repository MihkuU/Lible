Distributed grid collective operations
======================================

Scatter and gather operations with data type ``mpl::distributed_grid``.

.. literalinclude:: ../../../examples/distributed_grid_scatter_gather.cc
   :language: c++
