Vibrating string
================

Solves the one-dimensional wave equation via finite differences, MPI version.

.. literalinclude:: ../../../examples/vibrating_string_mpi.c
   :language: c


Solves the one-dimensional wave equation via finite differences, MPL version.

.. literalinclude:: ../../../examples/vibrating_string_mpl.cc
   :language: c++
