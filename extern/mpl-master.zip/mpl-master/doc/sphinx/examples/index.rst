Examples
========

.. toctree::

   hello_world
   standard_types
   struct
   arrays
   stl_container
   iterators
   blocking
   blocking_vector
   nonblocking
   nonblocking_mult
   probe
   communicator
   collective
   gather
   gatherv
   matrix_gather
   reduce
   layouts
   subarray
   parallel_sort
   vibrating_string
   distributed_grid
   distributed_grid_scatter_gather
   heat_equation_Jacobi_method
   heat_equation_successive_over-relaxation
   process_creation
   file
