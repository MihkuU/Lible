Constants
=========

MPL defines the following global constants:

.. doxygenvariable:: mpl::proc_null

.. doxygenvariable:: mpl::undefined

.. doxygenvariable:: mpl::root

.. doxygenvariable:: mpl::absolute

.. doxygenvariable:: mpl::bsend_overhead
