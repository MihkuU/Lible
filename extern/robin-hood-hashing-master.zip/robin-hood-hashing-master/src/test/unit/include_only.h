#ifndef INCLUDE_ONLY_H
#define INCLUDE_ONLY_H

int include_only();

#endif
